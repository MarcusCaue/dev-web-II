<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title> <?php echo e($title); ?> </title>
  <script src="https://kit.fontawesome.com/291706862f.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body class="bg-dark text-white">
    <div class="container">
      <div class="jumbotron mb-2 bg-secondary">
          <h1 class="text-center"><?php echo e($title); ?></h1>
      </div>
      <?php echo e($slot); ?>

      <div class="footer my-2 rounded">
          <p class="text-center bg-secondary">Cadastro de Contatos &copy; - Todos os Diretos Reservados</p>
      </div>
  </div>
</body>
</html>
   
 <?php /**PATH C:\Users\cauem\Documents\Desenvolvimento\Repositores_on_GitHub\laravel\laravel_web_II\agenda\resources\views/components/layout.blade.php ENDPATH**/ ?>