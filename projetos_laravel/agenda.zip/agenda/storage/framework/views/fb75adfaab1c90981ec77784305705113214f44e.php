<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => ['title' => 'Contatos Cadastrados']]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Contatos Cadastrados']); ?>
    
    <a href="/contatos/criar" class="btn btn-primary mb-2"> Cadastrar novo Contato </a>
    
    <ul class="list-group text-dark">
        <?php
            /* foreach ($contatos as $contato) {
                $html = "<li class='list-group-item d-flex justify-content-between align-items-center'>";
                $html .= "$contato->nome";
                $html .= "<span class='d-flex'>";
                $html .= '<a href="{{ route("contatos.edit", $contato->id) }}" class="btn btn-primary btn-sm mr-2"> <i class="fa-solid fa-pen"></i> </a>';
                $html .= "<a class='btn btn-danger btn-sm text-white'><i class='fa-solid fa-trash'></i></a>";
                $html .= "</span> </li>";

                echo $html;
            } */

            foreach($contatos as $contato): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <?= $contato->nome; ?>
                    
                    <span class="d-flex">
                        <a href="<?php echo e(route('contatos.edit', $contato->id)); ?>" class="btn btn-primary btn-sm mr-2"> <i class="fa-solid fa-pen"></i></a>
                        <a class="btn btn-danger btn-sm text-white"><i class="fa-solid fa-trash"></i></a>
                    </span>
                </li>        
        <?php endforeach; ?>
    </ul>      
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\Users\cauem\Documents\Desenvolvimento\Repositores_on_GitHub\laravel\laravel_web_II\agenda\resources\views/contatos/index.blade.php ENDPATH**/ ?>