<x-layout title="Contatos Cadastrados">
    
    <a href="/contatos/criar" class="btn btn-primary mb-2"> Cadastrar novo Contato </a>
    
    <ul class="list-group text-dark">
        <?php
            /* foreach ($contatos as $contato) {
                $html = "<li class='list-group-item d-flex justify-content-between align-items-center'>";
                $html .= "$contato->nome";
                $html .= "<span class='d-flex'>";
                $html .= '<a href="{{ route("contatos.edit", $contato->id) }}" class="btn btn-primary btn-sm mr-2"> <i class="fa-solid fa-pen"></i> </a>';
                $html .= "<a class='btn btn-danger btn-sm text-white'><i class='fa-solid fa-trash'></i></a>";
                $html .= "</span> </li>";

                echo $html;
            } */

            foreach($contatos as $contato): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <?= $contato->nome; ?>
                    
                    <span class="d-flex">
                        <a href="{{route('contatos.edit', $contato->id)}}" class="btn btn-primary btn-sm mr-2"> <i class="fa-solid fa-pen"></i></a>
                        <a class="btn btn-danger btn-sm text-white"><i class="fa-solid fa-trash"></i></a>
                    </span>
                </li>        
        <?php endforeach; ?>
    </ul>      
</x-layout>