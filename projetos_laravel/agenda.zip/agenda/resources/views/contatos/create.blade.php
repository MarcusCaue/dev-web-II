<x-layout title="Cadastrar Contato">
   <form action="/contatos/store" method="post">
        @csrf
        <div class="form-group">
            <label for="nome">Nome:</label>
            <input type="text" class="form-control" id="nome" name="nome" />
        </div>
        <button class="btn btn-primary"> Cadastrar </button>
   </form>
</x-layout>