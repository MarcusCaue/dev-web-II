<form action="{{ $action }}" method="post">
    @csrf
    @isset($nome)      
        @method('PUT')
    @endisset
    <div class="form-group">
        <label for="nome">Nome:</label>
        <input type="text" 
            class="form-control" 
            id="nome" 
            name="nome"
            @isset($nome) 
                value="{{ $nome }}"
            @endisset>
    </div>
    <button class="btn btn-primary">Salvar</button>
</form>