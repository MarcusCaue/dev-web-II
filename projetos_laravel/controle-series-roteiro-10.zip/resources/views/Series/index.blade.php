<x-layout title="Lista de Séries">
    @auth
    <a href="/series/create">
        <button class="btn btn-primary mb-4">Adicionar</button>
    </a>
    @endauth

    @isset($mensagemSucesso)
        <div class="alert alert-success">
                {{$mensagemSucesso}}
        </div>
    @endisset

    <ul class="list-group">
        <?php foreach($series as $serie): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                @auth <a href="{{ route('seasons.index', $serie->id) }}"> @endauth
                    {{ $serie->nome }}
                @auth </a> @endauth
                @auth
                <span class="d-flex">
                    <a href="{{route('series.edit', $serie->id)}}" 
                    class="btn btn-secondary btn-sm mr-1">
                        <i class="fa-solid fa-pen"></i>
                    </a>
                    <form action="{{route('series.destroy', $serie->id)}}" 
                    method="post">
                        @csrf
                        @method('delete')
                        <button class="btn btn-danger btn-sm">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                    </form>
                </span>  
                @endauth      
            </li>
        <?php endforeach; ?>
    </ul>
</x-layout>