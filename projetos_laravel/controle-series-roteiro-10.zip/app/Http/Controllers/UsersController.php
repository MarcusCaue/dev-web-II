<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;


class UsersController extends Controller
{
    public function create() {
        return view("users.create");
    }

    public function store(Request $req) {
        $data = $req->except(['_token']);
        $data['password'] = Hash::make($data['password']);
        $user = User::create($data);
        $user->save();
        Auth::login($user);

        return redirect(route("series.index"));
    }
}
