<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SeriesFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'nome'=> ['required', 'min:3', 'max:20']
        ];
    }

    public function messages()
    {
        return [
            'nome.required' => 'O campo nome é Obrigatório',
            'nome.min' => 'O campo nome deve ter pelo menos 3 caracteres',
            'nome.max' => 'O campo nome deve ter até 20 caracteres'
        ];
    }
}
