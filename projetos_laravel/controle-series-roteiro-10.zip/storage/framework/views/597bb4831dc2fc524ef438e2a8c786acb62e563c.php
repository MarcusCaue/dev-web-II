<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => ['title' => 'Login']]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Login']); ?> 
  <form method="post">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="email" class="form-label">E-mail</label>
        <input type="email" name="email" id="email" class="form-control"> 
      </div>

      <div class="form-group">
        <label for="password" class="form-label">Senha</label>
        <input type="password" name="password" id="password" class="form-control">
      </div>

      <button class="btn btn-primary mt-3">Entrar</button>
      <a href="<?php echo e(route('users.create')); ?>" class="btn btn-secondary mt-3">Registrar</a>
  </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH D:\Users\202010040042\Downloads\controle-series-prof-atualizado\controle-series (1)\resources\views/login/index.blade.php ENDPATH**/ ?>