<!doctype html>
<html lang="pt-BR">
<head>
    <script src="https://kit.fontawesome.com/291706862f.js&quot; crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport"
    content="width=device-width, user-scalable=no, initial-scale=1.0,
    maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?php echo e($title); ?> </title>
    <link rel="stylesheet"
    href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">.
    <script src="https://kit.fontawesome.com/3ece553b81.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(route('series.index')); ?>">Home</a>
        
                <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('logout')); ?>">Sair</a>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>">Entrar</a>
                <?php endif; ?>
            </div>
        </nav>
        
        <div class="jumbotron">
            <h1> <?php echo e($title); ?> </h1>
        </div>
       
        <?php if(isset($mensagemSucesso)): ?>
        <div class="alert alert-success">
                <?php echo e($mensagemSucesso); ?>

        </div>
        <?php endif; ?>
        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div>
            <?php echo e($slot); ?>

        </div>
        <br>
        <div class="footer">
            <hr>
            <p class="text-center text-white bg-secondary">
                Controle Series IFPB - &copy; Todos os direitos reservados - 2022.
            </p>
        </div>
    <div>
</body>
</html><?php /**PATH D:\Users\202010040042\Downloads\controle-series-prof-atualizado\controle-series (1)\resources\views/components/layout.blade.php ENDPATH**/ ?>