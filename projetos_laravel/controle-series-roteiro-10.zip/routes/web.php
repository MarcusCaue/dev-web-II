<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SeriesController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\SeasonsController;
use App\Http\Controllers\UsersController;
use App\Http\Middleware\Autenticador;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware("autenticador")->group(function() {
    Route::get('/', function () {
        return redirect(route("series.index"));
    });

    Route::get('/series/{series}/seasons', 
    'App\Http\Controllers\SeasonsController@index')->name('seasons.index');
    
    Route::get('/series', 
    'App\Http\Controllers\SeriesController@index')->name('series.index');

    Route::get('/series/{serie}/edit', 
    'App\Http\Controllers\SeriesController@edit')->name('series.edit');
});

Route::get('/series/create', 
    'App\Http\Controllers\SeriesController@create')->name('series.create');

Route::post('/series/store', 
    'App\Http\Controllers\SeriesController@store')->name('series.store');

Route::delete('/series/destroy/{serie}', 
    'App\Http\Controllers\SeriesController@destroy')->name('series.destroy');

Route::put('/series/{serie}', 
    'App\Http\Controllers\SeriesController@update')->name('series.update');

Route::get('/login', 'App\Http\Controllers\LoginController@index')->name('login');
Route::post('/login', 'App\Http\Controllers\LoginController@store')->name('signin');
Route::get('/logout', 'App\Http\Controllers\LoginController@destroy')->name('logout');
Route::get('/register', 'App\Http\Controllers\UsersController@create')->name('users.create');
Route::post('/register', 'App\Http\Controllers\UsersController@store')->name('users.store');

// Route::resource('/series', 'App\Http\Controllers\SeriesController@index')->except(['show'])->middleware('autenticador')->except('index');