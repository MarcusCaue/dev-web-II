<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Series;
use App\Models\Season;
use App\Models\Episode;
use App\Http\Requests\SeriesFormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Auth\AuthenticationException;
use App\Http\Middleware\Autenticador;
use App\Repositories\SeriesRepository;


class SeriesController extends Controller
{

    public function index(Request $req){
        if (Auth::check()) {
            $series = Series::all();
            $mensagemSucesso = session('mensagem.sucesso');
            return view("series.index")->with("series", $series)->with('mensagemSucesso', $mensagemSucesso);
        }

        throw new AuthenticationException();
    }

    public function create(){
        return view('series.create');
    }

    public function store(SeriesFormRequest $request){
        $serie = Series::create($request->all());
        $seasons = [];
        for ($i = 1; $i <= $request->seasonsQty; $i++) {
            $seasons[] = [
                'series_id' => $serie->id,
                'numero' => $i,
            ];
        }
        Season::insert($seasons);

        $episodes = [];
        foreach ($serie->seasons as $season) {
            for ($j = 1; $j <= $request->episodesPerSeason; $j++) {
                $episodes[] = [
                    'season_id' => $season->id,
                    'numero' => $j
                ];
            }
        }
        Episode::insert($episodes);
        $request->session()->flash('mensagemSucesso', "Serie $serie->nome adicionada com sucesso");

        return redirect('/series');
    }

    public function edit(Series $serie){
        return view('series.edit')->with('serie', $serie);
    }

    public function update(Series $serie, SeriesFormRequest $request){
        $nomeAnterior = $serie->nome;
        $nomeAtual = $request->nome;
        $serie->nome =  $nomeAtual;
        $serie->save();
        $request->session()->flash('mensagemSucesso', "Serie $nomeAnterior atualizada para $nomeAtual com sucesso");
        return redirect('/series');
    }

    public function destroy(Request $req){
        $nomeSerie = Series::find($req->serie)->nome;
        Series::destroy($req->serie);
        $req->session()->flash('mensagemSucesso', "Serie  $nomeSerie removida com sucesso");
        return redirect('/series');
    }


}
