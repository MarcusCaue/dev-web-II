<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => ['title' => 'Lista de Séries']]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Lista de Séries']); ?>
    <?php if(auth()->guard()->check()): ?>
    <a href="/series/create">
        <button class="btn btn-primary mb-4">Adicionar</button>
    </a>
    <?php endif; ?>

    <?php if(isset($mensagemSucesso)): ?>
        <div class="alert alert-success">
                <?php echo e($mensagemSucesso); ?>

        </div>
    <?php endif; ?>

    <ul class="list-group">
        <?php foreach($series as $serie): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <?php if(auth()->guard()->check()): ?> <a href="<?php echo e(route('seasons.index', $serie->id)); ?>"> <?php endif; ?>
                    <?php echo e($serie->nome); ?>

                <?php if(auth()->guard()->check()): ?> </a> <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                <span class="d-flex">
                    <a href="<?php echo e(route('series.edit', $serie->id)); ?>" 
                    class="btn btn-secondary btn-sm mr-1">
                        <i class="fa-solid fa-pen"></i>
                    </a>
                    <form action="<?php echo e(route('series.destroy', $serie->id)); ?>" 
                    method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger btn-sm">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                    </form>
                </span>  
                <?php endif; ?>      
            </li>
        <?php endforeach; ?>
    </ul>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH D:\Users\202010040042\Documents\controle-series\controle-series-atual\resources\views/series/index.blade.php ENDPATH**/ ?>