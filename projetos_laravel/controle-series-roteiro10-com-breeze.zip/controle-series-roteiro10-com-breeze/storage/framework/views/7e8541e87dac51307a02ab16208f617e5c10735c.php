<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Séries</title>
</head>
<body>
    <ul>
        <?php 
        foreach($series as $serie ){ ?>
            <li><?=$serie ?></li>
        <?php } ?>
        </ul>    
</body>
</html><?php /**PATH C:\Users\danyllo.albuquerque\Desktop\projeto-web-b\controle-series\resources\views/series/index.blade.php ENDPATH**/ ?>