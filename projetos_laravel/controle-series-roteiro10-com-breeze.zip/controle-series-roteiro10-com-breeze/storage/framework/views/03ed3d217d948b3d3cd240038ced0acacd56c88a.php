<form action="<?php echo e($action); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if(isset($nome)): ?>      
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
    <div class="form-group">
        <label for="nome">Nome:</label>
        <input type="text" 
            class="form-control" 
            id="nome" 
            name="nome"
            <?php if(isset($nome)): ?> 
                value="<?php echo e($nome); ?>"
            <?php endif; ?>>
    </div>
    <button class="btn btn-primary">Salvar</button>
</form><?php /**PATH D:\Users\202010040042\Documents\controle-series\controle-series-atual\resources\views/components/series/form.blade.php ENDPATH**/ ?>